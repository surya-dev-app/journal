import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/custom_bottom_bar.dart';
import 'frame_one_initial_page.dart';
import 'notifier/frame_one_notifier.dart';

class FrameOneScreen extends ConsumerStatefulWidget {
  const FrameOneScreen({Key? key}) : super(key: key);

  @override
  FrameOneScreenState createState() => FrameOneScreenState();
}

// ignore_for_file: must_be_immutable
class FrameOneScreenState extends ConsumerState<FrameOneScreen> {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      body: SafeArea(
        child: Navigator(
          key: navigatorKey,
          initialRoute: AppRoutes.frameOneInitialPage,
          onGenerateRoute:
              (routeSetting) => PageRouteBuilder(
                pageBuilder:
                    (ctx, ani, ani1) =>
                        getCurrentPage(context, routeSetting.name!),
                transitionDuration: Duration(seconds: 0),
              ),
        ),
      ),
      bottomNavigationBar: SizedBox(
        width: double.maxFinite,
        child: _buildBottomNavigationBar(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomNavigationBar(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: CustomBottomBar(
        onChanged: (BottomBarEnum type) {
          Navigator.pushNamed(
            navigatorKey.currentContext!,
            getCurrentRoute(type),
          );
        },
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Explore:
        return AppRoutes.frameOneInitialPage;
      case BottomBarEnum.Insights:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(BuildContext context, String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.frameOneInitialPage:
        return FrameOneInitialPage();
      default:
        return DefaultWidget();
    }
  }

  @override
  void initState() {
    super.initState();
  }
}
