import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';

/// This class is used in the [frame_one_initial_page] screen.
class FrameOneInitialModel extends Equatable {
  FrameOneInitialModel();

  FrameOneInitialModel copyWith() {
    return FrameOneInitialModel();
  }

  @override
  List<Object?> get props => [];
}
