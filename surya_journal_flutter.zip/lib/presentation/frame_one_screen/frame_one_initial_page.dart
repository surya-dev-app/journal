import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_outlined_button.dart';
import 'models/frame_one_initial_model.dart';
import 'notifier/frame_one_notifier.dart';

class FrameOneInitialPage extends StatefulWidget {
  const FrameOneInitialPage({Key? key}) : super(key: key);

  @override
  FrameOneInitialPageState createState() => FrameOneInitialPageState();
}

class FrameOneInitialPageState extends State<FrameOneInitialPage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        height: 914.h,
        child: Stack(
          alignment: Alignment.bottomCenter,
          children: [
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                height: 472.h,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgTopBackground,
                      height: 472.h,
                      width: double.maxFinite,
                    ),
                    _buildTopSection(context),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: double.maxFinite,
              child: Column(
                spacing: 32,
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildQuoteSection(context),
                  SizedBox(
                    width: double.maxFinite,
                    child: Divider(
                      color: theme.colorScheme.primary.withValues(alpha: 0.26),
                      indent: 26.h,
                      endIndent: 28.h,
                    ),
                  ),
                  _buildTodaysGoalSection(context),
                  CustomImageView(
                    imagePath: ImageConstant.imgBottomBackground,
                    height: 80.h,
                    width: double.maxFinite,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildTodaysGoalRow(
    BuildContext context, {
    required String createlanding,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomImageView(
          imagePath: ImageConstant.imgSettings,
          height: 6.h,
          width: 12.h,
          margin: EdgeInsets.only(top: 4.h),
        ),
        Align(
          alignment: Alignment.center,
          child: Padding(
            padding: EdgeInsets.only(left: 12.h),
            child: Text(
              createlanding,
              style: theme.textTheme.bodyMedium!.copyWith(
                color: appTheme.gray50,
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildTopSection(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        width: double.maxFinite,
        margin: EdgeInsets.only(top: 24.h),
        padding: EdgeInsets.symmetric(horizontal: 32.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: double.maxFinite,
              margin: EdgeInsets.symmetric(horizontal: 12.h),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("lbl_m".tr, style: theme.textTheme.bodySmall),
                  Text("lbl_t".tr, style: theme.textTheme.bodySmall),
                  Text("lbl_w".tr, style: theme.textTheme.bodySmall),
                  Text("lbl_t".tr, style: theme.textTheme.bodySmall),
                  SizedBox(
                    width: 10.h,
                    child: Column(
                      children: [
                        Text("lbl_f".tr, style: theme.textTheme.labelLarge),
                        SizedBox(width: double.maxFinite, child: Divider()),
                      ],
                    ),
                  ),
                  Text("lbl_s".tr, style: theme.textTheme.bodySmall),
                  Text("lbl_s".tr, style: theme.textTheme.bodySmall),
                ],
              ),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                height: 4.h,
                width: 4.h,
                margin: EdgeInsets.only(left: 16.h),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary,
                  borderRadius: BorderRadius.circular(2.h),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                height: 4.h,
                width: 4.h,
                margin: EdgeInsets.only(left: 1.h),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary,
                  borderRadius: BorderRadius.circular(2.h),
                ),
              ),
            ),
            Container(
              height: 4.h,
              width: 4.h,
              decoration: BoxDecoration(
                color: theme.colorScheme.primary,
                borderRadius: BorderRadius.circular(2.h),
              ),
            ),
            SizedBox(height: 38.h),
            Container(
              width: double.maxFinite,
              margin: EdgeInsets.only(right: 2.h),
              padding: EdgeInsets.symmetric(horizontal: 26.h, vertical: 28.h),
              decoration: AppDecoration.outlinePrimary.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder12,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 38.h,
                    width: 38.h,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primary,
                      borderRadius: BorderRadius.circular(18.h),
                    ),
                  ),
                  SizedBox(height: 18.h),
                  Text(
                    "msg_evening_reflection".tr,
                    style: theme.textTheme.headlineSmall,
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    "msg_how_was_your_day".tr,
                    style: theme.textTheme.bodyMedium,
                  ),
                  SizedBox(height: 14.h),
                  CustomOutlinedButton(
                    text: "lbl_reflect".tr,
                    margin: EdgeInsets.only(right: 4.h),
                    rightIcon: Container(
                      margin: EdgeInsets.only(left: 8.h),
                      child: CustomImageView(
                        imagePath: ImageConstant.imgArrowright,
                        height: 12.h,
                        width: 14.h,
                        fit: BoxFit.contain,
                      ),
                    ),
                    buttonStyle: CustomButtonStyles.none,
                    decoration:
                        CustomButtonStyles.gradientPrimaryToWhiteADecoration,
                  ),
                  SizedBox(height: 4.h),
                ],
              ),
            ),
            SizedBox(height: 16.h),
            Container(
              width: double.maxFinite,
              margin: EdgeInsets.only(left: 30.h, right: 40.h),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 4.h,
                    width: 4.h,
                    margin: EdgeInsets.only(top: 4.h),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primary,
                      borderRadius: BorderRadius.circular(2.h),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: EdgeInsets.only(left: 8.h),
                      child: Text(
                        "lbl_2_day_streak".tr,
                        style: CustomTextStyles.bodySmallGray50Light,
                      ),
                    ),
                  ),
                  Spacer(),
                  Container(
                    height: 4.h,
                    width: 4.h,
                    margin: EdgeInsets.only(top: 4.h),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primary,
                      borderRadius: BorderRadius.circular(2.h),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: EdgeInsets.only(left: 8.h),
                      child: Text(
                        "lbl_126_entries".tr,
                        style: CustomTextStyles.bodySmallGray50Light,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildQuoteSection(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.symmetric(horizontal: 24.h),
      child: Column(
        spacing: 6,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 4.h),
            child: Text(
              "lbl_hello_jake".tr,
              style: theme.textTheme.headlineLarge,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 4.h),
            child: Text(
              "msg_life_is_a_mirror".tr,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodyMedium,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 4.h),
            child: Text(
              "lbl_ernest_holmes".tr,
              style: CustomTextStyles.bodySmallGray400,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildTodaysGoalSection(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.only(left: 26.h, right: 28.h),
      child: Column(
        spacing: 16,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 4.h),
              child: Text(
                "lbl_today_s_goal".tr,
                style: theme.textTheme.headlineLarge,
              ),
            ),
          ),
          Container(
            width: double.maxFinite,
            margin: EdgeInsets.symmetric(horizontal: 10.h),
            child: _buildTodaysGoalRow(
              context,
              createlanding: "msg_develop_concept".tr,
            ),
          ),
          Container(
            width: double.maxFinite,
            margin: EdgeInsets.symmetric(horizontal: 10.h),
            child: _buildTodaysGoalRow(
              context,
              createlanding: "msg_create_landing_page".tr,
            ),
          ),
          Container(
            width: double.maxFinite,
            margin: EdgeInsets.symmetric(horizontal: 10.h),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 12.h,
                  width: 12.h,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary,
                    borderRadius: BorderRadius.circular(6.h),
                  ),
                ),
                Align(
                  alignment: Alignment.center,
                  child: Padding(
                    padding: EdgeInsets.only(left: 12.h),
                    child: Text(
                      "msg_practise_tennis".tr,
                      style: theme.textTheme.bodyMedium,
                    ),
                  ),
                ),
              ],
            ),
          ),
          CustomOutlinedButton(
            text: "lbl_add_goal".tr,
            rightIcon: Container(
              margin: EdgeInsets.only(left: 12.h),
              child: CustomImageView(
                imagePath: ImageConstant.imgArrowright,
                height: 12.h,
                width: 16.h,
                fit: BoxFit.contain,
              ),
            ),
            buttonStyle: CustomButtonStyles.outlinePrimary,
          ),
        ],
      ),
    );
  }
}
