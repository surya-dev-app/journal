import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import '../models/frame_one_initial_model.dart';
import '../models/frame_one_model.dart';
part 'frame_one_state.dart';

final frameOneNotifier =
    StateNotifierProvider.autoDispose<FrameOneNotifier, FrameOneState>(
      (ref) => FrameOneNotifier(
        FrameOneState(frameOneInitialModelObj: FrameOneInitialModel()),
      ),
    );

/// A notifier that manages the state of a FrameOne according to the event that is dispatched to it.
class FrameOneNotifier extends StateNotifier<FrameOneState> {
  FrameOneNotifier(FrameOneState state) : super(state);
}
