part of 'frame_one_notifier.dart';

/// Represents the state of FrameOne in the application.

// ignore_for_file: must_be_immutable
class FrameOneState extends Equatable {
  FrameOneState({this.frameOneInitialModelObj, this.frameOneModelObj});

  FrameOneModel? frameOneModelObj;

  FrameOneInitialModel? frameOneInitialModelObj;

  @override
  List<Object?> get props => [frameOneInitialModelObj, frameOneModelObj];
  FrameOneState copyWith({
    FrameOneInitialModel? frameOneInitialModelObj,
    FrameOneModel? frameOneModelObj,
  }) {
    return FrameOneState(
      frameOneInitialModelObj:
          frameOneInitialModelObj ?? this.frameOneInitialModelObj,
      frameOneModelObj: frameOneModelObj ?? this.frameOneModelObj,
    );
  }
}
