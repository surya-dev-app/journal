import 'package:flutter/material.dart';
import '../presentation/frame_one_screen/frame_one_screen.dart';

// ignore_for_file: must_be_immutable
class AppRoutes {
  static const String frameOneScreen = '/frame_one_screen';

  static const String frameOneInitialPage = '/frame_one_initial_page';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> routes = {
    frameOneScreen: (context) => FrameOneScreen(),
    initialRoute: (context) => FrameOneScreen(),
  };
}
