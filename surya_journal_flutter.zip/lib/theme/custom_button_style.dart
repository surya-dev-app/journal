import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A class that offers pre-defined button styles for customizing button appearance.
class CustomButtonStyles {
  // Gradient button style
  static BoxDecoration get gradientPrimaryToWhiteADecoration => BoxDecoration(
    borderRadius: BorderRadius.circular(12.h),
    border: Border.all(color: theme.colorScheme.primary, width: 1.h),
    boxShadow: [
      BoxShadow(
        color: theme.colorScheme.primary.withValues(alpha: 0.25),
        spreadRadius: 2.h,
        blurRadius: 2.h,
        offset: Offset(0, 4),
      ),
    ],
    gradient: LinearGradient(
      begin: Alignment(0.5, 0),
      end: Alignment(1.0, 0),
      colors: [
        theme.colorScheme.primary.withValues(alpha: 0.46),
        appTheme.whiteA70075,
      ],
    ),
  );
  // Outline button style
  static ButtonStyle get outlinePrimary => OutlinedButton.styleFrom(
    backgroundColor: Colors.transparent,
    side: BorderSide(color: theme.colorScheme.primary, width: 1),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.h)),
    padding: EdgeInsets.zero,
  );
  // text button style
  static ButtonStyle get none => ButtonStyle(
    backgroundColor: WidgetStateProperty.all<Color>(Colors.transparent),
    elevation: WidgetStateProperty.all<double>(0),
    padding: WidgetStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.zero),
    side: WidgetStateProperty.all<BorderSide>(
      BorderSide(color: Colors.transparent),
    ),
  );
}
