import 'package:flutter/material.dart';
import '../core/app_export.dart';

class AppDecoration {
  // Fill decorations
  static BoxDecoration get fillBlack => BoxDecoration(color: appTheme.black900);
  // Outline decorations
  static BoxDecoration get outlinePrimary => BoxDecoration(
    color: theme.colorScheme.primary.withValues(alpha: 0.45),
    boxShadow: [
      BoxShadow(
        color: theme.colorScheme.primary.withValues(alpha: 0.11),
        spreadRadius: 2.h,
        blurRadius: 2.h,
        offset: Offset(0, 4),
      ),
    ],
  );
  // Column decorations
  static BoxDecoration get column2 => BoxDecoration(
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgRectangle19),
      fit: BoxFit.fill,
    ),
  );
}

class BorderRadiusStyle {
  // Rounded borders
  static BorderRadius get roundedBorder12 => BorderRadius.circular(12.h);
}
