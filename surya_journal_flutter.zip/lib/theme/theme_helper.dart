import 'package:flutter/material.dart';
import '../core/app_export.dart';

LightCodeColors get appTheme => ThemeHelper().themeColor();
ThemeData get theme => ThemeHelper().themeData();

/// Helper class for managing themes and colors.

// ignore_for_file: must_be_immutable
class ThemeHelper {
  // The current app theme
  var _appTheme = PrefUtils().getThemeData();

  // A map of custom color themes supported by the app
  Map<String, LightCodeColors> _supportedCustomColor = {
    'lightCode': LightCodeColors(),
  };

  // A map of color schemes supported by the app
  Map<String, ColorScheme> _supportedColorScheme = {
    'lightCode': ColorSchemes.lightCodeColorScheme,
  };

  /// Returns the lightCode colors for the current theme.
  LightCodeColors _getThemeColors() {
    return _supportedCustomColor[_appTheme] ?? LightCodeColors();
  }

  /// Returns the current theme data.
  ThemeData _getThemeData() {
    var colorScheme =
        _supportedColorScheme[_appTheme] ?? ColorSchemes.lightCodeColorScheme;
    return ThemeData(
      visualDensity: VisualDensity.standard,
      colorScheme: colorScheme,
      textTheme: TextThemes.textTheme(colorScheme),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          backgroundColor: Colors.transparent,
          side: BorderSide(color: colorScheme.primary, width: 1.h),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.h),
          ),
          visualDensity: const VisualDensity(vertical: -4, horizontal: -4),
          padding: EdgeInsets.zero,
        ),
      ),
      dividerTheme: DividerThemeData(
        thickness: 2,
        space: 2,
        color: colorScheme.primary,
      ),
    );
  }

  /// Returns the lightCode colors for the current theme.
  LightCodeColors themeColor() => _getThemeColors();

  /// Returns the current theme data.
  ThemeData themeData() => _getThemeData();
}

/// Class containing the supported text theme styles.
class TextThemes {
  static TextTheme textTheme(ColorScheme colorScheme) => TextTheme(
    bodyLarge: TextStyle(
      color: colorScheme.primary,
      fontSize: 16.fSize,
      fontFamily: 'Inter',
      fontWeight: FontWeight.w300,
    ),
    bodyMedium: TextStyle(
      color: appTheme.gray50,
      fontSize: 14.fSize,
      fontFamily: 'Inter',
      fontWeight: FontWeight.w300,
    ),
    bodySmall: TextStyle(
      color: colorScheme.primary,
      fontSize: 12.fSize,
      fontFamily: 'Inter',
      fontWeight: FontWeight.w200,
    ),
    headlineLarge: TextStyle(
      color: colorScheme.primary,
      fontSize: 30.fSize,
      fontFamily: 'Inter',
      fontWeight: FontWeight.w300,
    ),
    headlineSmall: TextStyle(
      color: colorScheme.primary,
      fontSize: 24.fSize,
      fontFamily: 'Inter',
      fontWeight: FontWeight.w300,
    ),
    labelLarge: TextStyle(
      color: colorScheme.primary,
      fontSize: 12.fSize,
      fontFamily: 'Inter',
      fontWeight: FontWeight.w800,
    ),
  );
}

/// Class containing the supported color schemes.
class ColorSchemes {
  static final lightCodeColorScheme = ColorScheme.light(
    primary: Color(0XFFFFFFFF),
    secondaryContainer: Color(0X75E7E7E7),
    onPrimary: Color(0XFF813400),
  );
}

/// Class containing custom colors for a lightCode theme.
class LightCodeColors {
  // Black
  Color get black900 => Color(0XFF000000);
  // Gray
  Color get gray400 => Color(0XFFBEBEBE);
  Color get gray50 => Color(0XFFF8F8F8);
  // White
  Color get whiteA70075 => Color(0X75FFFEFE);
}
