// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Common images
  static String imgTopBackground = '$imagePath/img_top_background.png';

  static String imgArrowright = '$imagePath/img_arrowright.svg';

  static String imgSettings = '$imagePath/img_settings.svg';

  static String imgBottomBackground = '$imagePath/img_bottom_background.png';

  static String imgArrowup = '$imagePath/img_arrowup.svg';

  static String imgSuryaIconCommunity1 =
      '$imagePath/img_surya_icon_community_1.svg';

  static String imgRectangle19 = '$imagePath/img_rectangle_19.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
